﻿using System;
using System.Collections.Generic;

namespace RickMultipleGuitars
{
	public class Inventory
	{
		private List<Guitar> guitars = null;

		public Inventory() {
			guitars = new List<Guitar>();
		}

		public void addGuitar(string serialNumber, double price,
            Builder builder, string model, Typeg type, Wood backWood, Wood topWood) {

			Guitar guitar = new Guitar(serialNumber, price, builder, model, type, backWood, topWood);
			
			guitars.Add(guitar);
		}

		public Guitar getGuitar(string serialNumber) {
			foreach (Guitar guitar in guitars) {
				if (guitar.SerialNumber.Equals (serialNumber))
					return guitar;
			}
			return null;
		}

		public List<Guitar> search(GuitarSpec searchSpec) {

			List<Guitar> matchingGuitars = new List<Guitar>();
			foreach (Guitar guitar in guitars) {
                // Ignore serial number since that's unique
                // Ignore price since that's unique
                GuitarSpec guitarSpec = guitar.getSpec;

                string builder = searchSpec.Builder;
				if (!builder.Equals(guitarSpec.Builder))
					continue;
				
				string model = searchSpec.Model.ToLower();
				if ((model != null) && (!model.Equals("")) &&
					(!model.Equals(guitarSpec.Model.ToLower())))
					continue;
				
				string type = searchSpec.Typeg;
				if (!type.Equals(guitarSpec.Typeg))
					continue;

				string backWood = searchSpec.BackWood;
				if (!backWood.Equals(guitarSpec.BackWood))
					continue;

				string topWood = searchSpec .TopWood;
				if (!topWood.Equals(guitarSpec.TopWood))
					continue;

				matchingGuitars.Add (guitar);
			}
			return matchingGuitars;
		}
	}
}


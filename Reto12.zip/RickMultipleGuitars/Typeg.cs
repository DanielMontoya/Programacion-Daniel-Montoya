﻿using System;

namespace RickMultipleGuitars
{
	public enum Typeg
	{
		ACOUSTIC, ELECTRIC
	};


}


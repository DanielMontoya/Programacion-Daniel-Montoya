﻿using System;

namespace RickMultipleGuitars
{
	public enum Wood{INDIAN_ROSEWOOD, BRAZILIAN_ROSEWOOD, MAHOGANY, MAPLE,
		COCOBOLO, CEDAR, ADIRONDACK, ALDER, SITKA};
}

﻿using System;

namespace RickMultipleGuitars
{
	public enum Builder
	{
		FENDER, MARTIN, GIBSON, COLLINGS, OLSON, RYAN, PRS, ANY
	};
}

